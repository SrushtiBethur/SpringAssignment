package com.ttl.SpringBootJPACrudExample.controller;



import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class EmployeeController {

@Autowired
private EmployeeRepository obj;

@RequestMapping("/")
String home() {
return "Hello TTL Employee -- Spring Boot!";
}

@GetMapping("/employees")
public List<Employee> getAllEmployees()
{
return obj.findAll();
}

}