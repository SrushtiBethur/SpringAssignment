package com.ttl.SpringBootJPACrudExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaCrudExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaCrudExampleApplication.class, args);
	}

}
